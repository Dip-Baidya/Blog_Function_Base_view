from django.shortcuts import render
from .models import Post, Profile


def search_post(request):
    if request.method == 'POST':
        search_keyword = request.POST['search-keyword']
        posts = Post.objects.filter(title__contains=search_keyword)
        print("post list: ", posts)
        return render(request, 'blog/search.html', {'posts': posts})
    return render(request, 'blog/search.html')


def detail_post(request, post_id):
    try:
        post_obj = Post.objects.get(id=post_id)
        # profile_obj = Profile.objects.get(user=post_obj.author)

        context = {'post': post_obj}
        return render(request, 'blog/detail_post.html', context)
    except Exception as err:
        print(err)
        return render(request, '404.html')
